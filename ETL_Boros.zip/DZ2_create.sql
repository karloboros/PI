CREATE VIEW dDate AS
SELECT *
FROM [Boros0036531517_DZ1].[dbo].[dDate]

CREATE VIEW dTime AS
SELECT *
FROM [Boros0036531517_DZ1].[dbo].[dTime]

CREATE TABLE dProducts (
    ProductID INT PRIMARY KEY NOT NULL,
    ProductID_orig INT NOT NULL,
    CategoryID INT,
    SupplierID INT,
    ProductName NVARCHAR(40) NOT NULL,
    CountryOfOrigin NCHAR(25),
    QuantityPerUnit NVARCHAR(20),
    UnitPrice MONEY,
    UnitsInStock INT,
    CategoryName NVARCHAR(15) NOT NULL,
    CategoryDescription NVARCHAR(255),
    CategoryPicture IMAGE,
    SupplierCompanyName VARCHAR(100),
    SupplierContactName VARCHAR(100),
    SupplierContactTitle VARCHAR(100),
    SupplierAddress VARCHAR(100),
    SupplierPhone VARCHAR(20),
    SupplierFax VARCHAR(20),
    SupplierHomePage VARCHAR(255),
    SupplierCityID INT,
    SupplierPostalCode NVARCHAR(10),
    SupplierCityName NVARCHAR(15),
    SupplierRegion NVARCHAR(15),
    SupplierCountry NVARCHAR(15)
);

CREATE TABLE dCustomers (
    CustomerID NVARCHAR(5) PRIMARY KEY NOT NULL,
    CustomerID_orig NVARCHAR(5) NOT NULL,
    CompanyName NVARCHAR(40) NOT NULL,
    ContactName NVARCHAR(30),
    ContactTitle NVARCHAR(30),
    [Address] NVARCHAR(60),
    Phone NVARCHAR(24),
    Fax NVARCHAR(24),
    CustomerCityID INT,
    CustomerPostalCode NVARCHAR(10),
    CustomerCityName NVARCHAR(15),
    CustomerRegion NVARCHAR(15),
    CustomerCountry NVARCHAR(15)
);

CREATE TABLE dShippers (
    ShipperID INT PRIMARY KEY NOT NULL,
    ShipperID_orig INT NOT NULL,
    CompanyName NVARCHAR(40) NOT NULL,
    Phone NVARCHAR(24)
);

CREATE TABLE dEmployees (
    EmployeeID INT PRIMARY KEY NOT NULL,
    EmployeeID_orig INT NOT NULL,
    LastName NVARCHAR(20) NOT NULL,
    FirstName NVARCHAR(10) NOT NULL,
    Title NVARCHAR(30),
    TitleOfCourtesy NVARCHAR(25),
    BirthDate DATE,
    HireDate DATE,
    [Address] NVARCHAR(60),
    EmployeeCityID INT,
    EmployeePostalCode NVARCHAR(10),
    EmployeeCityName NVARCHAR(15),
    EmployeeRegion NVARCHAR(15),
    EmployeeCountry NVARCHAR(15),
    HomePhone NVARCHAR(24),
    Extension NVARCHAR(4),
    Photo IMAGE,
    Notes TEXT,
    ReportsTo INT
);

CREATE TABLE dShipments (
    ShipmentID INT PRIMARY KEY NOT NULL,
    ShipmentID_orig INT NOT NULL,
    ShipmentName NVARCHAR(40),
    ShipmentAddress NVARCHAR(60),
    ShipmentCityID INT,
    ShipmentPostalCode NVARCHAR(10),
    ShipmentCityName NVARCHAR(15),
    ShipmentRegion NVARCHAR(15),
    ShipmentCountry NVARCHAR(15)
);

CREATE TABLE cOrders (
    OrderID INT PRIMARY KEY,
    CustomerID NVARCHAR(5),
    EmployeeID INT,
    ShipperID INT,
    ShipmentID INT,
    OrderDate DATE,
    OrderTime TIME,
    RequiredDate DATE,
    RequiredTime TIME,
    ShippedDate DATE,
    ShippedTime TIME,
    OrderPrice MONEY,
    Freight MONEY,
    PaymentMethod NCHAR(10),
    FOREIGN KEY (CustomerID) REFERENCES dCustomers(CustomerID),
    FOREIGN KEY (EmployeeID) REFERENCES dEmployees(EmployeeID),
    FOREIGN KEY (ShipperID) REFERENCES dShippers(ShipperID),
    FOREIGN KEY (ShipmentID) REFERENCES dShipments(ShipmentID)
);

CREATE TABLE cOrderItems (
    ProductID INT,
    CustomerID NVARCHAR(5),
    ShipperID INT,
    EmployeeID INT,
    ShipmentID INT,
    OrderID INT,
    OrderDate DATE,
    OrderTime TIME,
    RequiredDate DATE,
    RequiredTime TIME,
    ShippedDate DATE,
    ShippedTime TIME,
    UnitPrice MONEY NOT NULL,
    Quantity INT NOT NULL,
    Discount REAL NOT NULL,
    DiscountDesc NCHAR(30),
    Total DECIMAL(10, 2),
    [Delay] VARCHAR(11) CHECK (Delay IN ('no delay', 'minor', 'moderate', 'significant')),
    PRIMARY KEY (ProductID, OrderID),
    FOREIGN KEY (ProductID) REFERENCES dProducts(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES dCustomers(CustomerID),
    FOREIGN KEY (ShipperID) REFERENCES dShippers(ShipperID),
    FOREIGN KEY (EmployeeID) REFERENCES dEmployees(EmployeeID),
    FOREIGN KEY (ShipmentID) REFERENCES dShipments(ShipmentID),
    FOREIGN KEY (OrderID) REFERENCES cOrders(OrderID)
);
