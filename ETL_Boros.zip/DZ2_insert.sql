INSERT INTO dShippers (ShipperID, ShipperID_orig, CompanyName, Phone)
SELECT s.ShipperID, s.ShipperID, s.CompanyName, s.Phone
FROM [NorthWind].[dbo].[Shippers] as s

INSERT INTO dEmployees (EmployeeID, EmployeeID_orig, LastName, FirstName, Title, TitleOfCourtesy, BirthDate, HireDate, [Address], EmployeeCityID, EmployeePostalCode, EmployeeCityName, EmployeeRegion, EmployeeCountry, HomePhone, Extension, Photo, Notes, ReportsTo)
SELECT s.EmployeeID, s.EmployeeID, s.LastName, s.FirstName, s.Title, s.TitleOfCourtesy, CAST(s.BirthDate AS DATE), CAST(s.HireDate AS DATE), s.Address, s.CityID, c.PostalCode, c.CityName, c.Region, c.Country, s.HomePhone, s.Extension, s.Photo, s.Notes, s.ReportsTo
FROM [NorthWind].[dbo].[Employees] as s
JOIN [NorthWind].[dbo].[City] as c ON s.CityID = c.CityID;

INSERT INTO dCustomers (CustomerID, CustomerID_orig, CompanyName, ContactName, ContactTitle, [Address], Phone, Fax, CustomerCityID, CustomerPostalCode, CustomerCityName, CustomerRegion, CustomerCountry)
SELECT s.CustomerID, s.CustomerID, s.CompanyName, s.ContactName, s.ContactTitle, s.Address, s.Phone, s.Fax, s.CityID, c.PostalCode, c.CityName, c.Region, c.Country
FROM [NorthWind].[dbo].[Customers] as s
JOIN [NorthWind].[dbo].[City] as c ON s.CityID = c.CityID;

INSERT INTO dShipments (ShipmentID, ShipmentID_orig, ShipmentName, ShipmentAddress, ShipmentCityID, ShipmentPostalCode, ShipmentCityName, ShipmentRegion, ShipmentCountry)
SELECT s.OrderID, s.OrderID, s.ShipName, s.ShipAddress, s.ShipCityId, c.PostalCode, c.CityName, c.Region, c.Country
FROM [NorthWind].[dbo].[Orders] as s
JOIN [NorthWind].[dbo].[City] as c ON s.ShipCityID = c.CityID;

UPDATE [Northwind_BorosSP].[dbo].[dShipments]
SET ShipmentID_orig = ShipmentID; 

INSERT INTO dProducts (ProductID, ProductID_orig, CategoryID, SupplierID, ProductName, CountryOfOrigin, QuantityPerUnit, UnitPrice, UnitsInStock, CategoryName, CategoryDescription, CategoryPicture, SupplierCompanyName, SupplierContactName, SupplierContactTitle, SupplierAddress, SupplierPhone, SupplierFax, SupplierHomePage, SupplierCityID, SupplierPostalCode, SupplierCityName, SupplierRegion, SupplierCountry)
SELECT p.ProductID, p.ProductID, c.CategoryID, s.SupplierID, p.ProductName, p.CountryOfOrigin, p.QuantityPerUnit, p.UnitPrice, p.UnitsInStock, c.CategoryName, c.Description, c.Picture, s.CompanyName, s.ContactName, s.ContactTitle, s.Address, s.Phone, s.Fax, s.HomePage, s.CityID, city.PostalCode, city.CityName, city.Region, city.Country
FROM [NorthWind].[dbo].[Products] as p
JOIN [NorthWind].[dbo].[Categories] as c ON p.CategoryID = c.CategoryID
JOIN [NorthWind].[dbo].[Suppliers] as s ON s.SupplierID = p.SupplierID
JOIN [NorthWind].[dbo].[City] as city ON s.CityID = city.CityID

INSERT INTO cOrders (OrderID, CustomerID, EmployeeID, ShipperID, ShipmentID, OrderDate, OrderTime, RequiredDate, RequiredTime, ShippedDate, ShippedTime, OrderPrice, Freight, PaymentMethod)
SELECT o.OrderID, c.CustomerID, e.EmployeeID, s.ShipperID, sh.ShipmentID, CAST(o.OrderDate AS DATE), CAST(o.OrderDate AS TIME), CAST(o.RequiredDate AS DATE), CAST(o.RequiredDate AS TIME), CAST(o.ShippedDate AS DATE), CAST(o.ShippedDate AS TIME),
	(SELECT ROUND(SUM(i.UnitPrice * i.Quantity * (1-i.Discount)),2) FROM [NorthWind].[dbo].[OrderItems] as i WHERE i.OrderID = o.OrderID), 
	o.Freight, o.PaymentMethod
FROM [NorthWind].[dbo].[Orders] as o
JOIN dCustomers as c ON o.CustomerID COLLATE Latin1_General_CI_AS = c.CustomerID
JOIN dEmployees as e ON e.EmployeeID = o.EmployeeID
JOIN dShippers as s ON s.ShipperID = o.ShipVia
JOIN dShipments as sh ON o.OrderID = sh.ShipmentID

INSERT INTO cOrderItems (ProductID, CustomerID, ShipperID, EmployeeID, ShipmentID, OrderID, OrderDate, OrderTime, RequiredDate, RequiredTime, ShippedDate, ShippedTime, UnitPrice, Quantity, Discount, DiscountDesc, Total, Delay)
SELECT p.ProductID, c.CustomerID, s.ShipperID, e.EmployeeID, sh.ShipmentID, i.OrderID, 
	CAST(OrderDate AS DATE), CAST(OrderTime AS TIME), 
	CAST(RequiredDate AS DATE), CAST(RequiredTime AS TIME), 
	CAST(ShippedDate AS DATE), CAST(ShippedTime AS TIME), 
	i.UnitPrice, i.Quantity, i.Discount, i.DiscountDesc, 
	i.Quantity * i.UnitPrice * (1-i.Discount), 
	'no delay'
FROM [NorthWind].[dbo].[OrderItems] as i
JOIN cOrders as o ON o.OrderID = i.OrderID
JOIN dCustomers as c ON o.CustomerID COLLATE Latin1_General_CI_AS = c.CustomerID
JOIN dEmployees as e ON e.EmployeeID = o.EmployeeID
JOIN dShippers as s ON s.ShipperID = o.ShipperID
JOIN dShipments as sh ON i.OrderID = sh.ShipmentID
JOIN dProducts as p ON p.ProductID = i.ProductID

UPDATE [Northwind_BorosSP].[dbo].[cOrderItems]
SET Delay = 
    CASE 
        WHEN DATEDIFF(DAY, OrderDate, ShippedDate) <= 2 THEN 'no delay'
        WHEN DATEDIFF(DAY, OrderDate, ShippedDate) <= 5 THEN 'minor'
        WHEN DATEDIFF(DAY, OrderDate, ShippedDate) <= 10 THEN 'moderate'
        ELSE 'significant'
    END;
